/*
 * example include file
 * */

void myPrint(void);
