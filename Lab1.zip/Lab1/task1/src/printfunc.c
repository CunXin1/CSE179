#include <stdio.h>
#include <learn_makefile.h>

void myPrint(void) {

  printf("Hello makefiles!\n");

  return;
}
