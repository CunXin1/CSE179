#include <learn_makefile.h>

int main() {
  // call a function in another file
  myPrint();

  return(0);
}
